package com.api.Restapi;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.api.Restapi.entity.User;

@RestController
public class UserController {

	@GetMapping("/users")
	public List<User> getAllUser(){
		List<User> userList = new ArrayList<>();
		User u1 = new User(11, "Pramod", 24, "Male");
		User u2 = new User(12, "Harshu", 18, "female");
		User u3 = new User(13, "Sampath", 20, "Male");
		User u4 = new User(14, "Spandana", 19 ,"female");
		
		userList.add(u1);
		userList.add(u2);
		userList.add(u3);
		userList.add(u4);
		
		return userList;
	}

}
