package cg.com.su;

package cg.com.su;

import java.util.ArrayList;

public class LinkedList {
	public static void main(String arg[]) {
		
		//Size is fixed
		//it is hetarogenuius elemnets
		//int a[] = {1,2,3};
		System.out.println(list);
		LinkedList<String> list=new LinkedList<String>();
		
		list.add("Audi");
		list.add("BMW");
		list.add("Jaguar");
		list.add("TATA");
		list.add("Honda");
		list.add("Thar");
		list.add("Ambasador");
		
		//list.get(1);
		System.out.println(list);
		
		
		
	}
}
